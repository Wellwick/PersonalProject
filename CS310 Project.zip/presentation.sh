#bin/bash

okular PersonalProject.potx.pdf --presentation &
java Network