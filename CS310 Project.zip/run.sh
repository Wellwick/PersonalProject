javac Network.javac
java Network